from flask import Flask, render_template, request, redirect, session, make_response, jsonify
import sqlite3
from datetime import datetime
import csv
from io import StringIO
import os

app = Flask(__name__)
app.secret_key = 'sua_chave_secreta'

# Criar pasta 'dados' se não existir
if not os.path.exists('dados'):
    os.makedirs('dados')

def get_db_path(username):
    return os.path.join('dados', f'{username}.db')

def get_db_connection(username):
    db_path = get_db_path(username)
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn

def create_tables(conn):
    conn.execute('''CREATE TABLE IF NOT EXISTS users
                    (id INTEGER PRIMARY KEY AUTOINCREMENT,
                     username TEXT UNIQUE NOT NULL,
                     password TEXT NOT NULL)''')
    conn.execute('''CREATE TABLE IF NOT EXISTS transactions
                    (id INTEGER PRIMARY KEY AUTOINCREMENT,
                     user_id INTEGER NOT NULL,
                     amount REAL NOT NULL,
                     description TEXT NOT NULL,
                     transaction_type TEXT NOT NULL,
                     date TEXT NOT NULL,
                     category_id INTEGER,
                     FOREIGN KEY (user_id) REFERENCES users (id),
                     FOREIGN KEY (category_id) REFERENCES categories (id))''')
    conn.execute('''CREATE TABLE IF NOT EXISTS notes
                    (id INTEGER PRIMARY KEY AUTOINCREMENT,
                     user_id INTEGER NOT NULL,
                     note TEXT NOT NULL,
                     FOREIGN KEY (user_id) REFERENCES users (id))''')
    conn.execute('''CREATE TABLE IF NOT EXISTS categories
                    (id INTEGER PRIMARY KEY AUTOINCREMENT,
                     user_id INTEGER NOT NULL,
                     name TEXT UNIQUE NOT NULL,
                     FOREIGN KEY (user_id) REFERENCES users (id))''')

@app.route('/')
def index():
    if 'user_id' in session:
        return redirect('/dashboard')
    return render_template('index.html')

@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']
    conn = get_db_connection(username)
    user = conn.execute('SELECT * FROM users WHERE username = ? AND password = ?',
                        (username, password)).fetchone()
    conn.close()
    if user:
        session['user_id'] = user['id']
        session['username'] = username
        return redirect('/dashboard')
    return redirect('/')

@app.route('/register', methods=['POST'])
def register():
    username = request.form['username']
    password = request.form['password']
    conn = get_db_connection(username)
    create_tables(conn)
    try:
        conn.execute('INSERT INTO users (username, password) VALUES (?, ?)',
                     (username, password))
        conn.commit()
        conn.close()
        return redirect('/')
    except sqlite3.IntegrityError:
        return "Nome de usuário já existe. Por favor, escolha outro."
    finally:
        conn.close()

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect('/')
    user_id = session['user_id']
    username = session['username']
    conn = get_db_connection(username)
    transactions = conn.execute('SELECT t.*, c.name AS category_name FROM transactions t LEFT JOIN categories c ON t.category_id = c.id WHERE t.user_id = ?',
                                (user_id,)).fetchall()
    notes = conn.execute('SELECT * FROM notes WHERE user_id = ?',
                         (user_id,)).fetchall()
    categories = conn.execute('SELECT * FROM categories WHERE user_id = ?', (user_id,)).fetchall()
    conn.close()

    # Calculate totals for entries, exits, and balance
    entries_total = sum(transaction['amount'] for transaction in transactions if transaction['transaction_type'] == 'entrada')
    exits_total = sum(transaction['amount'] for transaction in transactions if transaction['transaction_type'] == 'saida')
    balance = entries_total - exits_total

    # Convert to JSON to pass to JavaScript
    data = {
        'entries': entries_total,
        'exits': exits_total,
        'balance': balance
    }

    # Calcular dados para gráficos por categoria
    category_data = {}
    for category in categories:
        category_data[category['id']] = {
            'entries': 0,
            'exits': 0,
            'balance': 0
        }
        for transaction in transactions:
            if transaction['category_id'] == category['id']:
                if transaction['transaction_type'] == 'entrada':
                    category_data[category['id']]['entries'] += transaction['amount']
                else:
                    category_data[category['id']]['exits'] += transaction['amount']
        category_data[category['id']]['balance'] = category_data[category['id']]['entries'] - category_data[category['id']]['exits']

    return render_template('dashboard.html', transactions=transactions, balance=balance, data=data, notes=notes, categories=categories, category_data=category_data)

@app.route('/add_transaction', methods=['POST'])
def add_transaction():
    if 'user_id' not in session:
        return redirect('/')
    amount = float(request.form['amount'])
    description = request.form['description']
    transaction_type = request.form['type']
    date = datetime.strptime(request.form['date'], '%Y-%m-%d').strftime('%Y-%m-%d')
    category_name = request.form['category']
    user_id = session['user_id']
    username = session['username']

    conn = get_db_connection(username)
    category_id = conn.execute('SELECT id FROM categories WHERE user_id = ? AND name = ?', (user_id, category_name)).fetchone()
    if category_id:
        category_id = category_id['id']
    else:
        conn.execute('INSERT INTO categories (user_id, name) VALUES (?, ?)', (user_id, category_name))
        conn.commit()
        category_id = conn.execute('SELECT id FROM categories WHERE user_id = ? AND name = ?', (user_id, category_name)).fetchone()['id']

    conn.execute('INSERT INTO transactions (user_id, amount, description, transaction_type, date, category_id) VALUES (?, ?, ?, ?, ?, ?)',
                 (user_id, amount, description, transaction_type, date, category_id))
    conn.commit()
    conn.close()
    return redirect('/dashboard')

@app.route('/edit_category/<int:category_id>', methods=['GET', 'POST'])
def edit_category(category_id):
    if 'user_id' not in session:
        return redirect('/')
    user_id = session['user_id']
    username = session['username']
    conn = get_db_connection(username)
    category = conn.execute('SELECT * FROM categories WHERE id = ? AND user_id = ?',
                            (category_id, user_id)).fetchone()
    if not category:
        return "Categoria não encontrada."
    if request.method == 'POST':
        updated_name = request.form['category_name']
        conn.execute('UPDATE categories SET name = ? WHERE id = ?',
                     (updated_name, category_id))
        conn.commit()
        conn.close()
        return redirect('/dashboard')
    conn.close()
    return render_template('edit_category.html', category=category)

@app.route('/delete_category/<int:category_id>', methods=['POST'])
def delete_category(category_id):
    if 'user_id' not in session:
        return redirect('/')
    user_id = session['user_id']
    username = session['username']
    conn = get_db_connection(username)
    conn.execute('DELETE FROM categories WHERE id = ? AND user_id = ?', (category_id, user_id))
    conn.commit()
    conn.close()
    return redirect('/dashboard')

@app.route('/add_note', methods=['POST'])
def add_note():
    if 'user_id' not in session:
        return redirect('/')
    note = request.form['note']
    user_id = session['user_id']
    username = session['username']
    conn = get_db_connection(username)
    conn.execute('INSERT INTO notes (user_id, note) VALUES (?, ?)',
                 (user_id, note))
    conn.commit()
    conn.close()
    return redirect('/dashboard')

@app.route('/edit_note/<int:note_id>', methods=['GET', 'POST'])
def edit_note(note_id):
    if 'user_id' not in session:
        return redirect('/')
    username = session['username']
    conn = get_db_connection(username)
    note = conn.execute('SELECT * FROM notes WHERE id = ?',
                        (note_id,)).fetchone()
    if request.method == 'POST':
        updated_note = request.form['note']
        conn.execute('UPDATE notes SET note = ? WHERE id = ?',
                     (updated_note, note_id))
        conn.commit()
        conn.close()
        return redirect('/dashboard')
    conn.close()
    return render_template('edit_note.html', note=note)

@app.route('/delete_note/<int:note_id>', methods=['POST'])
def delete_note(note_id):
    if 'user_id' not in session:
        return redirect('/')
    username = session['username']
    conn = get_db_connection(username)
    conn.execute('DELETE FROM notes WHERE id = ?', (note_id,))
    conn.commit()
    conn.close()
    return redirect('/dashboard')

@app.route('/report')
def report():
    if 'user_id' not in session:
        return redirect('/')
    user_id = session['user_id']
    username = session['username']
    conn = get_db_connection(username)
    transactions = conn.execute('SELECT t.*, c.name AS category_name FROM transactions t LEFT JOIN categories c ON t.category_id = c.id WHERE t.user_id = ?',
                                (user_id,)).fetchall()
    conn.close()
    return render_template('report.html', transactions=transactions)

@app.route('/edit_transaction/<int:transaction_id>', methods=['GET', 'POST'])
def edit_transaction(transaction_id):
    if 'user_id' not in session:
        return redirect('/')
    user_id = session['user_id']
    username = session['username']
    conn = get_db_connection(username)
    transaction = conn.execute('SELECT t.*, c.name AS category_name FROM transactions t LEFT JOIN categories c ON t.category_id = c.id WHERE t.id = ?',
                               (transaction_id,)).fetchone()
    categories = conn.execute('SELECT * FROM categories WHERE user_id = ?', (user_id,)).fetchall()
    if request.method == 'POST':
        amount = float(request.form['amount'])
        description = request.form['description']
        transaction_type = request.form['type']
        date = datetime.strptime(request.form['date'], '%Y-%m-%d').strftime('%Y-%m-%d')
        category_name = request.form['category']

        # Obter o ID da categoria
        category_id = conn.execute('SELECT id FROM categories WHERE user_id = ? AND name = ?', (user_id, category_name)).fetchone()
        if category_id:
            category_id = category_id['id']
        else:
            # Se a categoria não existir, adicioná-la
            conn.execute('INSERT INTO categories (user_id, name) VALUES (?, ?)', (user_id, category_name))
            conn.commit()
            category_id = conn.execute('SELECT id FROM categories WHERE user_id = ? AND name = ?', (user_id, category_name)).fetchone()['id']

        conn.execute('UPDATE transactions SET amount = ?, description = ?, transaction_type = ?, date = ?, category_id = ? WHERE id = ?',
                     (amount, description, transaction_type, date, category_id, transaction_id))
        conn.commit()
        conn.close()
        return redirect('/report')
    conn.close()
    return render_template('edit_transaction.html', transaction=transaction, categories=categories)

@app.route('/delete_transaction/<int:transaction_id>', methods=['POST'])
def delete_transaction(transaction_id):
    if 'user_id' not in session:
        return redirect('/')
    username = session['username']
    conn = get_db_connection(username)
    conn.execute('DELETE FROM transactions WHERE id = ?', (transaction_id,))
    conn.commit()
    conn.close()
    return redirect('/report')

@app.route('/import_data', methods=['POST'])
def import_data():
    if 'user_id' not in session:
        return redirect('/')
    file = request.files['file']
    if file:
        content = file.read().decode('utf-8')
        data = csv.reader(StringIO(content))
        next(data)  # Pular o cabeçalho, se existir
        username = session['username']
        conn = get_db_connection(username)
        user_id = session['user_id']

        for row in data:
            try:
                # Desempacotar todas as cinco colunas
                description, amount, transaction_type, date, category_name = row

                # Converter 'amount' para float
                amount = float(amount)

                # Verificar se a categoria já existe; se não, adicionar
                category_id = conn.execute('SELECT id FROM categories WHERE user_id = ? AND name = ?', (user_id, category_name)).fetchone()
                if category_id:
                    category_id = category_id['id']
                else:
                    conn.execute('INSERT INTO categories (user_id, name) VALUES (?, ?)', (user_id, category_name))
                    conn.commit()
                    category_id = conn.execute('SELECT id FROM categories WHERE user_id = ? AND name = ?', (user_id, category_name)).fetchone()['id']

                # Inserir a transação no banco de dados
                conn.execute('INSERT INTO transactions (user_id, amount, description, transaction_type, date, category_id) VALUES (?, ?, ?, ?, ?, ?)',
                             (user_id, amount, description, transaction_type, date, category_id))
            except ValueError as e:
                print(f"Erro ao processar a linha: {row} - {str(e)}")
                continue
        conn.commit()
        conn.close()
    return redirect('/dashboard')

@app.route('/export_data')
def export_data():
    if 'user_id' not in session:
        return redirect('/')
    user_id = session['user_id']
    username = session['username']
    conn = get_db_connection(username)
    try:
        transactions = conn.execute('SELECT t.*, c.name AS category_name FROM transactions t LEFT JOIN categories c ON t.category_id = c.id WHERE t.user_id = ?',
                                    (user_id,)).fetchall()
        categories = conn.execute('SELECT * FROM categories WHERE user_id = ?', (user_id,)).fetchall()
        notes = conn.execute('SELECT * FROM notes WHERE user_id = ?', (user_id,)).fetchall()

        # Obter o nome do usuário
        user_name = conn.execute('SELECT username FROM users WHERE id = ?', (user_id,)).fetchone()['username']

        si = StringIO()
        cw = csv.writer(si)

        # Escrever transações
        cw.writerow(['description', 'amount', 'transaction_type', 'date', 'category_name'])
        for transaction in transactions:
            cw.writerow([
                transaction['description'],
                transaction['amount'],
                transaction['transaction_type'],
                transaction['date'],
                transaction['category_name']
            ])

        # Escrever notas
        cw.writerow([])  # Linha em branco para separar as seções
        cw.writerow(['Notes'])
        cw.writerow(['note_id', 'note'])
        for note in notes:
            cw.writerow([note['id'], note['note']])

        # Definir o nome do arquivo CSV com o nome do usuário e "Gastos_Pessoais"
        output = make_response(si.getvalue())
        output.headers["Content-Disposition"] = f"attachment; filename={user_name}_Gastos_Pessoais.csv"
        output.headers["Content-type"] = "text/csv"
        return output
    except Exception as e:
        print(f"Erro ao exportar dados: {str(e)}")
        return "Ocorreu um erro ao exportar os dados. Por favor, tente novamente."
    finally:
        conn.close()

@app.route('/add_category', methods=['POST'])
def add_category_route():
    if 'user_id' not in session:
        return redirect('/')
    category_name = request.form['category_name']
    user_id = session['user_id']
    username = session['username']
    conn = get_db_connection(username)
    try:
        conn.execute('INSERT INTO categories (user_id, name) VALUES (?, ?)', (user_id, category_name))
        conn.commit()
        conn.close()
        return jsonify({'success': True})
    except sqlite3.IntegrityError:
        return jsonify({'success': False, 'message': 'Categoria já existe.'})
    finally:
        conn.close()

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    session.pop('username', None)  # Remover o nome de usuário da sessão
    return redirect('/')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=1500, debug=True)
from flask import Flask, render_template, request, redirect, session, make_response, jsonify
import sqlite3
from datetime import datetime
import csv
from io import StringIO
import os

app = Flask(__name__)
app.secret_key = 'sua_chave_secreta'

# Criar pasta 'dados' se não existir
if not os.path.exists('dados'):
    os.makedirs('dados')

def get_db_path(username):
    return os.path.join('dados', f'{username}.db')

def get_db_connection(username):
    db_path = get_db_path(username)
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn

def create_tables(conn):
    conn.execute('''CREATE TABLE IF NOT EXISTS users
                    (id INTEGER PRIMARY KEY AUTOINCREMENT,
                     username TEXT UNIQUE NOT NULL,
                     password TEXT NOT NULL)''')
    conn.execute('''CREATE TABLE IF NOT EXISTS transactions
                    (id INTEGER PRIMARY KEY AUTOINCREMENT,
                     user_id INTEGER NOT NULL,
                     amount REAL NOT NULL,
                     description TEXT NOT NULL,
                     transaction_type TEXT NOT NULL,
                     date TEXT NOT NULL,
                     category_id INTEGER,
                     FOREIGN KEY (user_id) REFERENCES users (id),
                     FOREIGN KEY (category_id) REFERENCES categories (id))''')
    conn.execute('''CREATE TABLE IF NOT EXISTS notes
                    (id INTEGER PRIMARY KEY AUTOINCREMENT,
                     user_id INTEGER NOT NULL,
                     note TEXT NOT NULL,
                     FOREIGN KEY (user_id) REFERENCES users (id))''')
    conn.execute('''CREATE TABLE IF NOT EXISTS categories
                    (id INTEGER PRIMARY KEY AUTOINCREMENT,
                     user_id INTEGER NOT NULL,
                     name TEXT UNIQUE NOT NULL,
                     FOREIGN KEY (user_id) REFERENCES users (id))''')

@app.route('/')
def index():
    if 'user_id' in session:
        return redirect('/dashboard')
    return render_template('index.html')

@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']
    conn = get_db_connection(username)
    user = conn.execute('SELECT * FROM users WHERE username = ? AND password = ?',
                        (username, password)).fetchone()
    conn.close()
    if user:
        session['user_id'] = user['id']
        session['username'] = username
        return redirect('/dashboard')
    return redirect('/')

@app.route('/register', methods=['POST'])
def register():
    username = request.form['username']
    password = request.form['password']
    conn = get_db_connection(username)
    create_tables(conn)
    try:
        conn.execute('INSERT INTO users (username, password) VALUES (?, ?)',
                     (username, password))
        conn.commit()
        conn.close()
        return redirect('/')
    except sqlite3.IntegrityError:
        return "Nome de usuário já existe. Por favor, escolha outro."
    finally:
        conn.close()

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect('/')
    user_id = session['user_id']
    username = session['username']
    conn = get_db_connection(username)
    transactions = conn.execute('SELECT t.*, c.name AS category_name FROM transactions t LEFT JOIN categories c ON t.category_id = c.id WHERE t.user_id = ?',
                                (user_id,)).fetchall()
    notes = conn.execute('SELECT * FROM notes WHERE user_id = ?',
                         (user_id,)).fetchall()
    categories = conn.execute('SELECT * FROM categories WHERE user_id = ?', (user_id,)).fetchall()
    conn.close()

    # Calculate totals for entries, exits, and balance
    entries_total = sum(transaction['amount'] for transaction in transactions if transaction['transaction_type'] == 'entrada')
    exits_total = sum(transaction['amount'] for transaction in transactions if transaction['transaction_type'] == 'saida')
    balance = entries_total - exits_total

    # Convert to JSON to pass to JavaScript
    data = {
        'entries': entries_total,
        'exits': exits_total,
        'balance': balance
    }

    # Calcular dados para gráficos por categoria
    category_data = {}
    for category in categories:
        category_data[category['id']] = {
            'entries': 0,
            'exits': 0,
            'balance': 0
        }
        for transaction in transactions:
            if transaction['category_id'] == category['id']:
                if transaction['transaction_type'] == 'entrada':
                    category_data[category['id']]['entries'] += transaction['amount']
                else:
                    category_data[category['id']]['exits'] += transaction['amount']
        category_data[category['id']]['balance'] = category_data[category['id']]['entries'] - category_data[category['id']]['exits']

    return render_template('dashboard.html', transactions=transactions, balance=balance, data=data, notes=notes, categories=categories, category_data=category_data)

@app.route('/add_transaction', methods=['POST'])
def add_transaction():
    if 'user_id' not in session:
        return redirect('/')
    amount = float(request.form['amount'])
    description = request.form['description']
    transaction_type = request.form['type']
    date = datetime.strptime(request.form['date'], '%Y-%m-%d').strftime('%Y-%m-%d')
    category_name = request.form['category']
    user_id = session['user_id']
    username = session['username']

    conn = get_db_connection(username)
    category_id = conn.execute('SELECT id FROM categories WHERE user_id = ? AND name = ?', (user_id, category_name)).fetchone()
    if category_id:
        category_id = category_id['id']
    else:
        conn.execute('INSERT INTO categories (user_id, name) VALUES (?, ?)', (user_id, category_name))
        conn.commit()
        category_id = conn.execute('SELECT id FROM categories WHERE user_id = ? AND name = ?', (user_id, category_name)).fetchone()['id']

    conn.execute('INSERT INTO transactions (user_id, amount, description, transaction_type, date, category_id) VALUES (?, ?, ?, ?, ?, ?)',
                 (user_id, amount, description, transaction_type, date, category_id))
    conn.commit()
    conn.close()
    return redirect('/dashboard')

@app.route('/edit_category/<int:category_id>', methods=['GET', 'POST'])
def edit_category(category_id):
    if 'user_id' not in session:
        return redirect('/')
    user_id = session['user_id']
    username = session['username']
    conn = get_db_connection(username)
    category = conn.execute('SELECT * FROM categories WHERE id = ? AND user_id = ?',
                            (category_id, user_id)).fetchone()
    if not category:
        return "Categoria não encontrada."
    if request.method == 'POST':
        updated_name = request.form['category_name']
        conn.execute('UPDATE categories SET name = ? WHERE id = ?',
                     (updated_name, category_id))
        conn.commit()
        conn.close()
        return redirect('/dashboard')
    conn.close()
    return render_template('edit_category.html', category=category)

@app.route('/delete_category/<int:category_id>', methods=['POST'])
def delete_category(category_id):
    if 'user_id' not in session:
        return redirect('/')
    user_id = session['user_id']
    username = session['username']
    conn = get_db_connection(username)
    conn.execute('DELETE FROM categories WHERE id = ? AND user_id = ?', (category_id, user_id))
    conn.commit()
    conn.close()
    return redirect('/dashboard')

@app.route('/add_note', methods=['POST'])
def add_note():
    if 'user_id' not in session:
        return redirect('/')
    note = request.form['note']
    user_id = session['user_id']
    username = session['username']
    conn = get_db_connection(username)
    conn.execute('INSERT INTO notes (user_id, note) VALUES (?, ?)',
                 (user_id, note))
    conn.commit()
    conn.close()
    return redirect('/dashboard')

@app.route('/edit_note/<int:note_id>', methods=['GET', 'POST'])
def edit_note(note_id):
    if 'user_id' not in session:
        return redirect('/')
    username = session['username']
    conn = get_db_connection(username)
    note = conn.execute('SELECT * FROM notes WHERE id = ?',
                        (note_id,)).fetchone()
    if request.method == 'POST':
        updated_note = request.form['note']
        conn.execute('UPDATE notes SET note = ? WHERE id = ?',
                     (updated_note, note_id))
        conn.commit()
        conn.close()
        return redirect('/dashboard')
    conn.close()
    return render_template('edit_note.html', note=note)

@app.route('/delete_note/<int:note_id>', methods=['POST'])
def delete_note(note_id):
    if 'user_id' not in session:
        return redirect('/')
    username = session['username']
    conn = get_db_connection(username)
    conn.execute('DELETE FROM notes WHERE id = ?', (note_id,))
    conn.commit()
    conn.close()
    return redirect('/dashboard')

@app.route('/report')
def report():
    if 'user_id' not in session:
        return redirect('/')
    user_id = session['user_id']
    username = session['username']
    conn = get_db_connection(username)
    transactions = conn.execute('SELECT t.*, c.name AS category_name FROM transactions t LEFT JOIN categories c ON t.category_id = c.id WHERE t.user_id = ?',
                                (user_id,)).fetchall()
    conn.close()
    return render_template('report.html', transactions=transactions)

@app.route('/edit_transaction/<int:transaction_id>', methods=['GET', 'POST'])
def edit_transaction(transaction_id):
    if 'user_id' not in session:
        return redirect('/')
    user_id = session['user_id']
    username = session['username']
    conn = get_db_connection(username)
    transaction = conn.execute('SELECT t.*, c.name AS category_name FROM transactions t LEFT JOIN categories c ON t.category_id = c.id WHERE t.id = ?',
                               (transaction_id,)).fetchone()
    categories = conn.execute('SELECT * FROM categories WHERE user_id = ?', (user_id,)).fetchall()
    if request.method == 'POST':
        amount = float(request.form['amount'])
        description = request.form['description']
        transaction_type = request.form['type']
        date = datetime.strptime(request.form['date'], '%Y-%m-%d').strftime('%Y-%m-%d')
        category_name = request.form['category']

        # Obter o ID da categoria
        category_id = conn.execute('SELECT id FROM categories WHERE user_id = ? AND name = ?', (user_id, category_name)).fetchone()
        if category_id:
            category_id = category_id['id']
        else:
            # Se a categoria não existir, adicioná-la
            conn.execute('INSERT INTO categories (user_id, name) VALUES (?, ?)', (user_id, category_name))
            conn.commit()
            category_id = conn.execute('SELECT id FROM categories WHERE user_id = ? AND name = ?', (user_id, category_name)).fetchone()['id']

        conn.execute('UPDATE transactions SET amount = ?, description = ?, transaction_type = ?, date = ?, category_id = ? WHERE id = ?',
                     (amount, description, transaction_type, date, category_id, transaction_id))
        conn.commit()
        conn.close()
        return redirect('/report')
    conn.close()
    return render_template('edit_transaction.html', transaction=transaction, categories=categories)

@app.route('/delete_transaction/<int:transaction_id>', methods=['POST'])
def delete_transaction(transaction_id):
    if 'user_id' not in session:
        return redirect('/')
    username = session['username']
    conn = get_db_connection(username)
    conn.execute('DELETE FROM transactions WHERE id = ?', (transaction_id,))
    conn.commit()
    conn.close()
    return redirect('/report')

@app.route('/import_data', methods=['POST'])
def import_data():
    if 'user_id' not in session:
        return redirect('/')
    file = request.files['file']
    if file:
        content = file.read().decode('utf-8')
        data = csv.reader(StringIO(content))
        next(data)  # Pular o cabeçalho, se existir
        username = session['username']
        conn = get_db_connection(username)
        user_id = session['user_id']

        for row in data:
            try:
                # Desempacotar todas as cinco colunas
                description, amount, transaction_type, date, category_name = row

                # Converter 'amount' para float
                amount = float(amount)

                # Verificar se a categoria já existe; se não, adicionar
                category_id = conn.execute('SELECT id FROM categories WHERE user_id = ? AND name = ?', (user_id, category_name)).fetchone()
                if category_id:
                    category_id = category_id['id']
                else:
                    conn.execute('INSERT INTO categories (user_id, name) VALUES (?, ?)', (user_id, category_name))
                    conn.commit()
                    category_id = conn.execute('SELECT id FROM categories WHERE user_id = ? AND name = ?', (user_id, category_name)).fetchone()['id']

                # Inserir a transação no banco de dados
                conn.execute('INSERT INTO transactions (user_id, amount, description, transaction_type, date, category_id) VALUES (?, ?, ?, ?, ?, ?)',
                             (user_id, amount, description, transaction_type, date, category_id))
            except ValueError as e:
                print(f"Erro ao processar a linha: {row} - {str(e)}")
                continue
        conn.commit()
        conn.close()
    return redirect('/dashboard')

@app.route('/export_data')
def export_data():
    if 'user_id' not in session:
        return redirect('/')
    user_id = session['user_id']
    username = session['username']
    conn = get_db_connection(username)
    try:
        transactions = conn.execute('SELECT t.*, c.name AS category_name FROM transactions t LEFT JOIN categories c ON t.category_id = c.id WHERE t.user_id = ?',
                                    (user_id,)).fetchall()
        categories = conn.execute('SELECT * FROM categories WHERE user_id = ?', (user_id,)).fetchall()
        notes = conn.execute('SELECT * FROM notes WHERE user_id = ?', (user_id,)).fetchall()

        # Obter o nome do usuário
        user_name = conn.execute('SELECT username FROM users WHERE id = ?', (user_id,)).fetchone()['username']

        si = StringIO()
        cw = csv.writer(si)

        # Escrever transações
        cw.writerow(['description', 'amount', 'transaction_type', 'date', 'category_name'])
        for transaction in transactions:
            cw.writerow([
                transaction['description'],
                transaction['amount'],
                transaction['transaction_type'],
                transaction['date'],
                transaction['category_name']
            ])

        # Escrever notas
        cw.writerow([])  # Linha em branco para separar as seções
        cw.writerow(['Notes'])
        cw.writerow(['note_id', 'note'])
        for note in notes:
            cw.writerow([note['id'], note['note']])

        # Definir o nome do arquivo CSV com o nome do usuário e "Gastos_Pessoais"
        output = make_response(si.getvalue())
        output.headers["Content-Disposition"] = f"attachment; filename={user_name}_Gastos_Pessoais.csv"
        output.headers["Content-type"] = "text/csv"
        return output
    except Exception as e:
        print(f"Erro ao exportar dados: {str(e)}")
        return "Ocorreu um erro ao exportar os dados. Por favor, tente novamente."
    finally:
        conn.close()

@app.route('/add_category', methods=['POST'])
def add_category_route():
    if 'user_id' not in session:
        return redirect('/')
    category_name = request.form['category_name']
    user_id = session['user_id']
    username = session['username']
    conn = get_db_connection(username)
    try:
        conn.execute('INSERT INTO categories (user_id, name) VALUES (?, ?)', (user_id, category_name))
        conn.commit()
        conn.close()
        return jsonify({'success': True})
    except sqlite3.IntegrityError:
        return jsonify({'success': False, 'message': 'Categoria já existe.'})
    finally:
        conn.close()

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    session.pop('username', None)  # Remover o nome de usuário da sessão
    return redirect('/')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=1500, debug=True)
